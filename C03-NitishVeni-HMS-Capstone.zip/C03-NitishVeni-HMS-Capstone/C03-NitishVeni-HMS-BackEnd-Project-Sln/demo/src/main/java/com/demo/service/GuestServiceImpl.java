package com.demo.service;

public class GuestServiceImpl implements GuestService{
}
