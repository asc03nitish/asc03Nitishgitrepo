package com.demo.service;

public class HotelServiceImpl implements HotelService{
}
