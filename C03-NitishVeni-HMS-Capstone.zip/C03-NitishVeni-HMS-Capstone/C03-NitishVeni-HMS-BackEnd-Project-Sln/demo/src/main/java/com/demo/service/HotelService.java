package com.demo.service;

public interface HotelService {
}
