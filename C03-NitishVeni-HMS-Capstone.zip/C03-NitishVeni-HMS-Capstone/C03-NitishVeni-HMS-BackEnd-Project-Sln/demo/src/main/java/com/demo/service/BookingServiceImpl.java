package com.demo.service;

public class BookingServiceImpl implements BookingService{
}
