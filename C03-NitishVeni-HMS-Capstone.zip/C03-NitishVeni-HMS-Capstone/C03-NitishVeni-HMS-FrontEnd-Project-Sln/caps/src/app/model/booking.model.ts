export class Booking {
    bookingId: number;
    hotelId: number;
    guestId: number;
    checkInDate: Date;
    checkOutDate: Date;
    totalAmount: number;
  }
  
  