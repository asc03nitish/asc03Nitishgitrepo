export class Facility {
    facilityId: number;
    hotelId: number;
    facilityName: string;
    description: string;
    availability: string;
    cost: number;
  }
  