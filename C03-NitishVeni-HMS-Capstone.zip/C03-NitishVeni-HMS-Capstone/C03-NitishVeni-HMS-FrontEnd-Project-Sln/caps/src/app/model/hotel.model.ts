export class Hotel {
    hotelId: number; 
    name: string; 
    location: string; 
    pricePerNight: number; 
    availability: string; 
    contact: string; 
    dateAdded: Date; 
  }
  